$(document).ready(function() {
	$('#end a').click(function (e) {
  e.preventDefault()
  $(this).tab('show')
});
$('#profile a').click(function (e) {
  e.preventDefault()
  $(this).tab('show')
});	
$('#messages a').click(function (e) {
  e.preventDefault()
  $(this).tab('show')
});
});